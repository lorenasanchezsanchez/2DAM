package com.example.reconocimientovoz

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

sealed class VoiceState {
    data object Idle : VoiceState()
    data object Listening : VoiceState()
    data class Partial(val text: String) : VoiceState()
    data class Result(val text: String) : VoiceState()
    data class Error(val message: String) : VoiceState()
}

class SpeechRecognitionManager(context: Context) {
    private val appContext = context.applicationContext
    private var recognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val state: StateFlow<VoiceState> = _state.asStateFlow()

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(appContext)

    fun startListening() {
        if (!isAvailable()) {
            _state.value = VoiceState.Error("No hay un servicio de reconocimiento de voz instalado.")
            return
        }

        try {
            if (recognizer == null) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(appContext).also { sr ->
                    sr.setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _state.value = VoiceState.Listening
                        }
                        override fun onBeginningOfSpeech() {
                            _state.value = VoiceState.Listening
                        }
                        override fun onRmsChanged(rmsdB: Float) {}
                        override fun onBufferReceived(buffer: ByteArray?) {}
                        override fun onEndOfSpeech() {
                            // Se mantiene el estado hasta recibir resultado/error.
                        }
                        override fun onError(error: Int) {
                            val message = when (error) {
                                SpeechRecognizer.ERROR_AUDIO -> "Error de audio."
                                SpeechRecognizer.ERROR_CLIENT -> "Reconocimiento interrumpido."
                                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta permiso para usar el micrófono."
                                SpeechRecognizer.ERROR_NETWORK -> "Error de red."
                                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Tiempo de espera de red agotado."
                                SpeechRecognizer.ERROR_NO_MATCH -> "No se ha entendido el comando. Inténtalo otra vez."
                                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "El reconocedor está ocupado."
                                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No se ha detectado voz."
                                else -> "Error de reconocimiento ($error)."
                            }
                            _state.value = VoiceState.Error(message)
                        }
                        override fun onResults(results: Bundle?) {
                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val text = matches?.firstOrNull()
                            _state.value = if (text.isNullOrBlank()) {
                                VoiceState.Error("No se ha obtenido ningún resultado.")
                            } else {
                                VoiceState.Result(text)
                            }
                        }
                        override fun onPartialResults(partialResults: Bundle?) {
                            val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            matches?.firstOrNull()?.let { _state.value = VoiceState.Partial(it) }
                        }
                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Di un comando, por ejemplo: ir a ajustes")
            }
            _state.value = VoiceState.Listening
            recognizer?.startListening(intent)
        } catch (e: SecurityException) {
            _state.value = VoiceState.Error("No hay permiso para usar el micrófono.")
        } catch (e: Exception) {
            _state.value = VoiceState.Error("No se pudo iniciar el reconocimiento: ${e.localizedMessage ?: "error"}")
        }
    }

    fun stopListening() {
        try {
            recognizer?.stopListening()
        } catch (_: Exception) {
            _state.value = VoiceState.Idle
        }
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
        _state.value = VoiceState.Idle
    }
}
