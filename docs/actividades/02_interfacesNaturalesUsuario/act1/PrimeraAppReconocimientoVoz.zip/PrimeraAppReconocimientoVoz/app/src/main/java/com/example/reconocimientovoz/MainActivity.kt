package com.example.reconocimientovoz

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.reconocimientovoz.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var speechManager: SpeechRecognitionManager
    private val commandProcessor = VoiceCommandProcessor()
    private var listeningAnimator: ObjectAnimator? = null
    private var helpDialog: AlertDialog? = null
    private var isListening = false

    private val requestAudioPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else showAction("Permiso de micrófono denegado")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        speechManager = SpeechRecognitionManager(this)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(binding.fragmentContainer.id, HomeFragment())
                .commit()
        }

        binding.btnTheme.setOnClickListener { toggleTheme() }
        binding.fabMicrofono.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    checkPermissionAndStart()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    stopListening()
                    true
                }
                else -> true
            }
        }

        lifecycleScope.launch {
            speechManager.state.collect { state ->
                when (state) {
                    is VoiceState.Idle -> setListeningUi(false, "Micrófono inactivo")
                    is VoiceState.Listening -> setListeningUi(true, "Escuchando…")
                    is VoiceState.Partial -> {
                        setListeningUi(true, "Escuchando…")
                        binding.txtRecognized.text = "Parcial: ${state.text}"
                    }
                    is VoiceState.Result -> {
                        setListeningUi(false, "Reconocimiento completado")
                        binding.txtRecognized.text = "Resultado final: ${state.text}"
                        handleCommand(state.text)
                    }
                    is VoiceState.Error -> {
                        setListeningUi(false, state.message)
                        binding.txtRecognized.text = state.message
                    }
                }
            }
        }
    }

    private fun checkPermissionAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            requestAudioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        isListening = true
        speechManager.startListening()
    }

    private fun stopListening() {
        if (isListening) {
            isListening = false
            speechManager.stopListening()
        }
    }

    private fun setListeningUi(listening: Boolean, status: String) {
        binding.txtListeningStatus.text = status
        if (listening) {
            binding.listeningCircle.setBackgroundResource(R.drawable.circle_listening)
            if (listeningAnimator == null) {
                val sx = PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.45f, 1f)
                val sy = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.45f, 1f)
                listeningAnimator = ObjectAnimator.ofPropertyValuesHolder(binding.listeningCircle, sx, sy).apply {
                    duration = 850
                    repeatCount = ObjectAnimator.INFINITE
                    interpolator = AccelerateDecelerateInterpolator()
                }
            }
            if (listeningAnimator?.isStarted != true) listeningAnimator?.start()
        } else {
            listeningAnimator?.cancel()
            binding.listeningCircle.scaleX = 1f
            binding.listeningCircle.scaleY = 1f
            binding.listeningCircle.setBackgroundResource(R.drawable.circle_idle)
        }
    }

    private fun handleCommand(text: String) {
        when (commandProcessor.process(text)) {
            VoiceCommand.GoHome -> {
                navigate(HomeFragment())
                showAction("Navegación: inicio")
            }
            VoiceCommand.GoSettings -> {
                navigate(SettingsFragment())
                showAction("Navegación: ajustes")
            }
            VoiceCommand.DarkTheme -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                showAction("Tema oscuro activado")
            }
            VoiceCommand.LightTheme -> {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                showAction("Tema claro activado")
            }
            VoiceCommand.ShowMessage -> {
                Snackbar.make(binding.root, "¡Comando de voz ejecutado correctamente!", Snackbar.LENGTH_LONG).show()
                showAction("Se ha mostrado un mensaje")
            }
            VoiceCommand.OpenDialog -> {
                showCommandDialog()
                showAction("Diálogo abierto")
            }
            VoiceCommand.CloseDialog -> {
                if (helpDialog?.isShowing == true) {
                    helpDialog?.dismiss()
                    showAction("Diálogo cerrado")
                } else {
                    showAction("No hay ningún diálogo abierto")
                }
            }
            VoiceCommand.Help -> {
                showHelpDialog()
                showAction("Ayuda mostrada")
            }
            VoiceCommand.Unknown -> {
                showAction("Comando no reconocido: \"$text\". Di «ayuda» para ver los comandos.")
            }
        }
    }

    private fun navigate(fragment: androidx.fragment.app.Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(binding.fragmentContainer.id, fragment)
            .commit()
    }

    private fun toggleTheme() {
        val current = AppCompatDelegate.getDefaultNightMode()
        val dark = current == AppCompatDelegate.MODE_NIGHT_YES ||
            (current == AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM &&
                (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES)
        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES
        )
    }

    private fun showCommandDialog() {
        helpDialog?.dismiss()
        helpDialog = AlertDialog.Builder(this)
            .setTitle("Diálogo de ejemplo")
            .setMessage("Este diálogo se ha abierto mediante un comando de voz. Di «cerrar diálogo» para cerrarlo.")
            .setPositiveButton("Cerrar") { dialog, _ -> dialog.dismiss() }
            .create()
        helpDialog?.show()
    }

    private fun showHelpDialog() {
        helpDialog?.dismiss()
        helpDialog = AlertDialog.Builder(this)
            .setTitle("Comandos disponibles")
            .setMessage(
                "• Inicio / ir a inicio\\n" +
                "• Ajustes / ir a ajustes\\n" +
                "• Tema oscuro / tema claro\\n" +
                "• Mostrar mensaje\\n" +
                "• Abrir diálogo / cerrar diálogo\\n" +
                "• Ayuda"
            )
            .setPositiveButton("Entendido", null)
            .create()
        helpDialog?.show()
    }

    private fun showAction(message: String) {
        binding.txtLastAction.text = "Acción: $message"
    }

    override fun onDestroy() {
        listeningAnimator?.cancel()
        helpDialog?.dismiss()
        speechManager.destroy()
        super.onDestroy()
    }
}
