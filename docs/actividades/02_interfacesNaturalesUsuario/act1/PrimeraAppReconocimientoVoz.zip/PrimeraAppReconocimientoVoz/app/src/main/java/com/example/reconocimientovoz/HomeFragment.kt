package com.example.reconocimientovoz

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import com.example.reconocimientovoz.databinding.FragmentHomeBinding
import com.google.android.material.snackbar.Snackbar

class HomeFragment : Fragment(R.layout.fragment_home) {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val binding = FragmentHomeBinding.bind(view)
        binding.btnShowMessage.setOnClickListener {
            Snackbar.make(view, "¡Hola! Este es el mensaje de ejemplo.", Snackbar.LENGTH_LONG).show()
        }
        binding.btnOpenDialog.setOnClickListener {
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Diálogo de ejemplo")
                .setMessage("Este diálogo se ha abierto desde el fragmento Inicio.")
                .setPositiveButton("Cerrar", null)
                .show()
        }
    }
}
