package com.example.reconocimientovoz

import java.text.Normalizer
import java.util.Locale

sealed class VoiceCommand {
    data object GoHome : VoiceCommand()
    data object GoSettings : VoiceCommand()
    data object DarkTheme : VoiceCommand()
    data object LightTheme : VoiceCommand()
    data object ShowMessage : VoiceCommand()
    data object OpenDialog : VoiceCommand()
    data object CloseDialog : VoiceCommand()
    data object Help : VoiceCommand()
    data object Unknown : VoiceCommand()
}

class VoiceCommandProcessor {
    fun process(text: String): VoiceCommand {
        val normalized = Normalizer.normalize(text.lowercase(Locale("es", "ES")), Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .trim()

        return when {
            normalized.contains("inicio") || normalized.contains("pantalla principal") ||
                normalized == "home" -> VoiceCommand.GoHome
            normalized.contains("ajustes") || normalized.contains("configuracion") ||
                normalized.contains("configuración") -> VoiceCommand.GoSettings
            normalized.contains("tema oscuro") || normalized.contains("modo oscuro") ||
                normalized == "oscuro" -> VoiceCommand.DarkTheme
            normalized.contains("tema claro") || normalized.contains("modo claro") ||
                normalized == "claro" -> VoiceCommand.LightTheme
            normalized.contains("mostrar mensaje") || normalized == "mensaje" ||
                normalized.contains("ensename un mensaje") -> VoiceCommand.ShowMessage
            normalized.contains("abrir dialogo") || normalized.contains("abre dialogo") ||
                normalized.contains("abrir cuadro") -> VoiceCommand.OpenDialog
            normalized.contains("cerrar dialogo") || normalized.contains("cierra dialogo") ||
                normalized.contains("cerrar cuadro") -> VoiceCommand.CloseDialog
            normalized.contains("ayuda") || normalized.contains("comandos") -> VoiceCommand.Help
            else -> VoiceCommand.Unknown
        }
    }
}
