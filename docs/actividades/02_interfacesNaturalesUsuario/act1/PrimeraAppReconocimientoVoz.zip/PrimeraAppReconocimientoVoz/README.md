# Primera app de reconocimiento de voz en Android

Proyecto Android Studio en Kotlin con `SpeechRecognizer`, reconocimiento parcial y final,
cinco o más comandos, navegación entre fragmentos, cambio de tema claro/oscuro, mensaje,
diálogo y círculo pulsante mientras escucha.

## Requisitos
- Android Studio reciente.
- JDK 17 (seleccionable en Android Studio: Settings > Build Tools > Gradle > Gradle JDK).
- Android SDK 35 instalado.
- Dispositivo/emulador Android con servicio de reconocimiento de voz. Para probar voz real,
  es preferible un dispositivo con Google Speech Services y conexión a Internet.

## Abrir y ejecutar
1. Descomprime el ZIP.
2. En Android Studio, selecciona **Open** y elige la carpeta `PrimeraAppReconocimientoVoz`.
3. Espera a que termine la sincronización de Gradle.
4. Ejecuta la configuración `app` en un dispositivo o emulador.
5. Acepta el permiso de micrófono.
6. Pulsa **Mantener para hablar** y di uno de los comandos de ejemplo.

## Comandos de voz
- "inicio" / "ir a inicio"
- "ajustes" / "ir a ajustes"
- "tema oscuro" / "modo oscuro"
- "tema claro" / "modo claro"
- "mostrar mensaje" / "mensaje"
- "abrir diálogo" / "abrir dialogo"
- "cerrar diálogo" / "cerrar dialogo"
- "ayuda" (muestra los comandos disponibles)

El botón funciona como push-to-talk: mantener pulsado para escuchar y soltar para detener.
El círculo de la parte superior pulsa mientras la escucha está activa.

## Notas
- La API de reconocimiento depende de que el dispositivo tenga un servicio de voz instalado.
- Los resultados parciales pueden no llegar en todos los servicios/dispositivos.
- No se necesita clave de API ni librería externa de IA.
